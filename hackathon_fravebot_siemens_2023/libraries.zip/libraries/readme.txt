pip install library_name-version-pyversion-platform.whl
